//
//  UILabel+StringFrame.h
//  haihua
//
//  Created by by.huang on 16/6/5.
//  Copyright © 2016年 by.huang. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UILabel (StringFrame)

- (CGSize)boundingRectWithSize:(CGSize)size;

@end